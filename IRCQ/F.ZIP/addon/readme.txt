
DCC LOCK ADDON by str8ridah >> �Str8 Scriptin Inc. 1997-98
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
If you use this in a public script give me credit.  There's no 
such thing as a "reference".  Ripping addons will get you no respect.

SETUP
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
TO LOAD: In mirc type /load -rs <dcclock.mrc directory>
EG: /load -rs c:\mirc\addons\dcclock.mrc
After that it'll set itself up.

If for some reason the addon doesn't work your probably have
other addons or scripting using the events of this script.
In mirc press Alt + R go to file/order and move dcclock.mrc to
the top of the list.

=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
God said he would send his one begotten son to lead the wild
in to the ways of the man.  Follow me...
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
�$Makaveli$� [-Outlaw'd-Immortal-] by str8ridah
http://www.geocities.com/SiliconValley/Lakes/4808/makaveli.html
